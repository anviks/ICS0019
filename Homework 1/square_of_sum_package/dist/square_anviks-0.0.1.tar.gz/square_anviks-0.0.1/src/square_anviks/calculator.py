def square_of_sum(a: int | float, b: int | float) -> int | float:
    if type(a) not in (int, float) or type(b) not in (int, float):
        return -1
    return (a + b) ** 2


if __name__ == '__main__':
    print(square_of_sum(4, 2))
